Config extension 1.0.2 by sfPlayer

Thread: http://forums.alliedmods.net/showthread.php?t=69167

Installation:

Simply extract the contents (config.ext/*) of this zip file into your addons/sourcemod folder.

License: GPLv3