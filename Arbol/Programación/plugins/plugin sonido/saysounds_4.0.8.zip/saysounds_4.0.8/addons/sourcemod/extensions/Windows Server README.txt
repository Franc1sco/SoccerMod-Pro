If the "Say Sounds" plugin fails to load because the "Sound Info Library" extension doesn't load
you have to do one of the following:

- Install the Microsoft Visual C++ 2010 SP1 Redistributable Package (x86) on your server
	https://www.microsoft.com/download/en/details.aspx?id=8328
	
OR

-  use the previous version of the extension which doesn't have that dependency
	https://forums.alliedmods.net/attachment.php?attachmentid=101452&d=1333379451